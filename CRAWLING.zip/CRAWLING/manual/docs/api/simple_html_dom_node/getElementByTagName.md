# getElementByTagName

```php
getElementByTagName ( string $name ) : object
```

| Parameter | Description
| --------- | -----------
| `name`    | Tag name.

Returns the first element with the specified tag name.