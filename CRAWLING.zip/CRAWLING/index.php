<?php
include_once("simple_html_dom.php");

// set target url to crawl
$url = "https://www.facebook.com/"; // change this

// open the web page
$html = new simple_html_dom();
$html->load_file($url);

// array to store scraped links
$links = [
    ['id', 'title', 'poster', 'overview', 'release_date', 'genres'],
    [],
];

// print_r($links);

// crawl the webpage for links
foreach($html->find("a") as $link){
    foreach($link->href as $url) {
        array_push($links, $url);
    }
}

// remove duplicates from the links array
// $links = array_unique($links);


$path = 'links.csv';

// set output headers to download file



$fp = fopen($path, 'w'); // open in write only mode (write at the start of the file)
foreach ($links as $row) {
    fputcsv($fp, $row);
}
fclose($fp);

header("Content-Description: File Transfer"); 
header("Content-Type: application/octet-stream"); 
header("Content-Disposition: attachment; filename=\"". $path . "\"");
readfile ($path);
?>